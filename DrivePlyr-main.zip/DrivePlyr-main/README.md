# DrivePlyr
Google Drive Proxy Video Player with Many Powerful HTML5 Players Hidden ID and Many Features 🚀


![drive-logo](https://user-images.githubusercontent.com/66713844/189491013-27a5bc30-6057-4e08-b66b-d5184f20060d.png)


## Websites

- https://sh20raj.github.io/DrivePlyr/
- https://sh20raj.github.io/VideoPlyr/
- https://driveplyr.appspages.online/

## GitHub

- https://github.com/SH20RAJ/DrivePlyr
- https://github.com/SH20RAJ/VideoPlyr
